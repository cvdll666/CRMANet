import math

import torch
try:
    # flash_attn_func_cuda 若能 import 成功则为函数，否则保持 None
    from flash_attn import flash_attn_func as flash_attn_func_cuda
except Exception:
    flash_attn_func_cuda = None

def indexing(x, indices, chunk_size=-1):
    """
    inputs:
        - x: 4d-tensor with shape [b, h, n, d]
        - indices: 3d-tensor with shape [b, h, s] where each entry should be in [0, n-1]
    output:
        - out: 4d-tensor with shape [b, h, s, d] where out[i,j] = x[i,j][indices[i,j],:]
    """
    if chunk_size < 0 or (chunk_size > 0 and x.shape[-2] % chunk_size == 0):
        return x.gather(2, indices.unsqueeze(-1).expand(-1, -1, -1, x.shape[-1]))
    else:
        x = x.gather(2, indices.unsqueeze(-1).expand(-1, -1, -1, x.shape[-1]))
        new_n = math.ceil(x.shape[2] / chunk_size) * chunk_size
        if new_n <= 0 or new_n - x.shape[2] <= 0:
            import pdb
            pdb.set_trace()
        return torch.nn.functional.pad(
            x, (0, 0, 0, new_n - x.shape[2]), mode="constant", value=0.0
        )


def add_self_attentions(attn1, lse1, attn2, lse2):
    """
    inputs:
        - attn1, attn2: 4d-tensors with shape [b, h, n, d]
        - lse1, lse2: 4d-tensors of log-sum-exp with shape [b, h, n, 1]
    output:
        - attn
        = (attn1 * exp(lse1) + attn2 * exp(lse2)) / (exp(lse1) + exp(lse2))
        ...
    """
    c = (1 / (1 + (lse2 - lse1).exp())).to(dtype=attn1.dtype)
    attn = c * attn1 + (1 - c) * attn2
    lse = lse1 - (c + torch.finfo(lse1.dtype).eps).log()
    return attn, lse


def _gpu_is_ampere_or_newer(device: torch.device):
    """
    Helper: return True if device is CUDA and compute capability >= 8.0 (Ampere+) .
    If device is not CUDA or capability can't be determined, return False.
    """
    try:
        if not (device is not None and device.type == "cuda"):
            return False
        # torch.cuda.get_device_capability accepts device (torch.device) in modern torch
        cap = torch.cuda.get_device_capability(device)
        # cap is (major, minor). Ampere begins at major >= 8.
        return cap[0] >= 8
    except Exception:
        return False


def exact_attention(q, k, v, softmax_scale, causal=False, bias=None):
    """
    Numerically-correct (but fast when possible) exact attention implementation.

    Behavior:
      - If q's dtype is not float16/bfloat16 -> falls back to plain matmul-softmax (float32)
      - If q is float16/bfloat16 AND flash_attn_func_cuda is available AND running on Ampere+ GPU:
            -> use flash_attn (fast path)
        else:
            -> fallback to matmul-softmax, doing intermediate ops in float32 for stability,
               then cast result back to input dtype.

    Returns:
      - out: [b, h, n, d]
      - lse: log-sum-exp tensor [b, h, n, 1]
    """
    # If inputs are not half/bfloat16, simple PyTorch matmul implementation (works on CPU and GPU)
    if q.dtype not in [torch.bfloat16, torch.float16]:
        # regular (higher-precision) path
        qk = q @ k.transpose(-1, -2) * softmax_scale
        if causal:
            # add -inf above diagonal
            qk = qk + (
                torch.ones(q.shape[2], k.shape[2], device=q.device)
                .triu(1)
                .reshape(1, 1, q.shape[2], k.shape[2])
                * torch.finfo(qk.dtype).min
            )
        out = qk.softmax(dim=-1) @ v
        lse = torch.logsumexp(qk, dim=-1, keepdim=True)
        return out, lse

    # from here: q.dtype is float16 or bfloat16
    # check whether we can use flash_attn fast path
    can_use_flash = (
        flash_attn_func_cuda is not None
        and q.is_cuda
        and _gpu_is_ampere_or_newer(q.device)
    )

    if can_use_flash:
        # use flash_attn (its API expects [b, seq, head, dim] transposed -> we keep the earlier pattern)
        out, lse, _ = flash_attn_func_cuda(
            q.transpose(1, 2),
            k.transpose(1, 2),
            v.transpose(1, 2),
            softmax_scale=softmax_scale,
            causal=causal,
            return_attn_probs=True,
        )
        out = out.transpose(1, 2)
        # lse returned is [b, h, n] (likely), make it [b,h,n,1]
        lse = lse.detach()
        if lse.dim() == 3:
            # ensure same seq length as out
            if lse.shape[2] != out.shape[2]:
                lse = lse[:, :, : out.shape[2]]
            lse = lse.unsqueeze(-1)
        elif lse.dim() == 4:
            # already has last dim maybe 1
            pass
        else:
            lse = lse.unsqueeze(-1)
        return out, lse

    # fallback: do matmul-softmax in float32 for numerical stability, then cast back
    # Move temporaries to float32 (on same device)
    q32 = q.to(torch.float32)
    k32 = k.to(torch.float32)
    v32 = v.to(torch.float32)
    # compute qk
    qk = q32 @ k32.transpose(-1, -2)
    qk = qk * float(softmax_scale)
    if causal:
        qk = qk + (
            torch.ones(qk.shape[2], qk.shape[3], device=qk.device)
            .triu(1)
            .reshape(1, 1, qk.shape[2], qk.shape[3])
            * torch.finfo(qk.dtype).min
        )
    lse32 = torch.logsumexp(qk, dim=-1, keepdim=True)  # [b,h,n,1]
    probs = torch.softmax(qk, dim=-1)  # float32
    out32 = probs @ v32  # float32
    # cast back to original dtype
    out = out32.to(q.dtype)
    lse = lse32.to(q.dtype)
    return out, lse


def exact_attention_cuda(query, key, value, softmax_scale, causal, bias=None):
    """
    Explicit CUDA-only interface: try to use flash_attn if available on Ampere+.
    If not available or GPU is unsupported, raise a clear error telling user to
    use exact_attention (which has automatic fallback).

    NOTE: In many code paths you can just call exact_attention(...) directly
    which will choose the best available implementation.
    """
    # sanity: require CUDA
    if not query.is_cuda:
        raise RuntimeError("exact_attention_cuda expects query on CUDA device.")

    can_use_flash = (
        flash_attn_func_cuda is not None
        and _gpu_is_ampere_or_newer(query.device)
    )
    if not can_use_flash:
        raise RuntimeError(
            "FlashAttention is not available on this GPU (requires Ampere or newer) "
            "or flash_attn is not installed. Call exact_attention(...) instead, which "
            "will automatically fall back to a safe matmul-softmax implementation."
        )

    out, lse, _ = flash_attn_func_cuda(
        query.transpose(1, 2),
        key.transpose(1, 2),
        value.transpose(1, 2),
        softmax_scale=softmax_scale,
        causal=causal,
        return_attn_probs=True,
    )
    out = out.transpose(1, 2)
    lse = lse.unsqueeze(-1)
    return out, lse
