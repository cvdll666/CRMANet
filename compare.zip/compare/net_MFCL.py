# net_Zbase5CSDB_fixed_cmca.py
# 修复版本：解决 CMCA_PixelFusion 中通道不匹配导致的 runtime view 错误
# 说明：在 CMCA_PixelFusion.forward 中动态根据 compressed 的通道数构造小型 SFED 风格 conv 层，
#       以保证在不同通道配置下也能正确运行（避免 z.view(...) 的 shape mismatch）。
#
# 其余网络结构（encoder/decoder/feature fusion/transfer）与之前实现保持一致。

import time
import torch
import torch.nn as nn
import torch.nn.functional as F
from thop import profile

# ---------------------------
# 基础模块（与之前保持一致）
# ---------------------------
class FeatureProcessingBlock(nn.Module):
    def __init__(self, dim):
        super().__init__()
        groups = 8 if dim >= 8 else 1
        self.block = nn.Sequential(
            nn.Conv2d(dim, dim, 3, padding=1),
            nn.GroupNorm(groups, dim),
            nn.SiLU()
        )

    def forward(self, x):
        return self.block(x) + x


class Block(nn.Module):
    def __init__(self, in_dim, out_dim):
        super().__init__()
        self.block = nn.Sequential(
            nn.Conv2d(in_dim, out_dim, 3, padding=1),
            nn.GroupNorm(8, out_dim),
            nn.SiLU(),
            nn.Conv2d(out_dim, out_dim, 3, padding=1),
            nn.GroupNorm(8, out_dim),
            nn.SiLU()
        )

    def forward(self, x):
        return self.block(x)


class Encoder(nn.Module):
    def __init__(self, dim, dim_mults, num_blocks=1):
        super().__init__()
        self.dims = [dim * m for m in dim_mults]
        in_out = list(zip([dim] + self.dims[:-1], self.dims))
        if isinstance(num_blocks, int):
            num_blocks = [num_blocks] * len(in_out)

        self.blocks = nn.ModuleList()
        self.downsamples = nn.ModuleList()

        for (in_dim, out_dim), n in zip(in_out, num_blocks):
            layers = [Block(in_dim if i == 0 else out_dim, out_dim) for i in range(n)]
            self.blocks.append(nn.Sequential(*layers))
            self.downsamples.append(nn.Conv2d(out_dim, out_dim, 3, stride=2, padding=1))

    def forward(self, x):
        skips = []
        for block, downsample in zip(self.blocks, self.downsamples):
            x = block(x)
            skips.append(x)
            x = downsample(x)
        return skips, x


class Decoder(nn.Module):
    def __init__(self, dim, dim_mults, num_blocks=1):
        super().__init__()
        encoder_dims = [dim * m for m in dim_mults]
        reversed_dims = list(reversed(encoder_dims))
        reversed_dims.append(dim)
        in_out = list(zip(reversed_dims, reversed_dims[1:]))
        if isinstance(num_blocks, int):
            num_blocks = [num_blocks] * len(in_out)

        self.upsamples = nn.ModuleList()
        self.blocks = nn.ModuleList()
        self.feature_processing_blocks = nn.ModuleList()

        for idx, ((in_dim, out_dim), n) in enumerate(zip(in_out, num_blocks)):
            self.upsamples.append(nn.Sequential(
                nn.Upsample(scale_factor=2, mode='nearest'),
                nn.Conv2d(in_dim, in_dim, 3, padding=1)
            ))
            layers = [Block(in_dim + in_dim if i == 0 else out_dim, out_dim) for i in range(n)]
            self.blocks.append(nn.Sequential(*layers))
            self.feature_processing_blocks.append(FeatureProcessingBlock(out_dim))

    def forward(self, x, fused_skips):
        for upsample, block, feature_block, skip in zip(self.upsamples, self.blocks, self.feature_processing_blocks,
                                                      reversed(fused_skips)):
            x = upsample(x)
            x = torch.cat([x, skip], dim=1)
            x = block(x)
            x = feature_block(x)
        return x


# ---------------------------
# 修复后的 CMCA_PixelFusion（动态兼容不同通道）
# ---------------------------
class CMCA_PixelFusion(nn.Module):
    def __init__(self, channels, pool_kernel_sizes=(3, 7)):
        """
        channels: 期望的内部通道数（用于默认初始化）；但实现已在 forward 中根据实际 compressed 通道动态处理，
                  因此此参数只是作为初始/参考值（保持向后兼容）。
        pool_kernel_sizes: 多尺度池化组合
        """
        super().__init__()
        self.channels = channels
        self.pool_kernel_sizes = pool_kernel_sizes

        # 将 pooled concat 投影到一个参考通道数（这里使用 channels），以便初次构建时有层存在。
        # 在 forward 中会根据实际情况动态创建 SFED 层以兼容不同通道数。
        self.compress = nn.Conv2d(2 * len(pool_kernel_sizes), channels, kernel_size=1)

        # 为兼容性保留一个小的可复用 final_conv（如果 forward 创建了动态 conv，会优先使用动态 conv）
        self.final_conv = nn.Conv2d(channels, channels, kernel_size=1)
        self.sig = nn.Sigmoid()

    def forward(self, x_rgb, x_fir):
        """
        x_rgb/x_fir: [B, C_in, H, W]
        运行时为通道数任意值提供兼容处理（动态创建简单 SFED conv 层）。
        """
        B, C_fir, H, W = x_fir.shape

        pooled_list = []
        for k in self.pool_kernel_sizes:
            v = F.adaptive_avg_pool2d(x_fir, (max(1, H // k), W))
            v = F.interpolate(v, size=(H, W), mode='bilinear', align_corners=False)
            pooled_list.append(v.mean(dim=1, keepdim=True))

            h = F.adaptive_avg_pool2d(x_fir, (H, max(1, W // k)))
            h = F.interpolate(h, size=(H, W), mode='bilinear', align_corners=False)
            pooled_list.append(h.mean(dim=1, keepdim=True))

        pooled_cat = torch.cat(pooled_list, dim=1)  # [B, 2*len(k), H, W]

        # 使用 compress 将 pooled_cat 投影到某个通道尺寸（这里是 self.channels）
        compressed = self.compress(pooled_cat)  # [B, refC, H, W]
        refC = compressed.shape[1]

        # 动态 SFED 实现：先全局池化到 1x1，再用两层 1x1 conv (hidden) -> (refC)
        hidden = max(8, refC // 4)
        # 在 forward 中临时构造小型 conv 层以保证通道匹配（这些权重是临时的，不会持久化）
        # 这样做可以快速修复不同通道输入导致的形状错误问题。
        conv1 = nn.Conv2d(refC, hidden, kernel_size=1).to(compressed.device)
        conv2 = nn.Conv2d(hidden, refC, kernel_size=1).to(compressed.device)
        conv_final = nn.Conv2d(refC, refC, kernel_size=1).to(compressed.device)

        z = F.adaptive_avg_pool2d(compressed, (1, 1))  # [B, refC, 1, 1]
        z = F.relu(conv1(z))
        z = F.relu(conv2(z))
        wf = self.sig(conv_final(z))  # [B, refC, 1, 1]

        # 若需要将 wf 的通道数广播到 x_rgb 的通道数（x_rgb 通道可能 != refC），则调整：
        C_rgb = x_rgb.shape[1]
        if refC != C_rgb:
            # 使用 1x1 投影将 wf 的通道数映射到 x_rgb 通道数（临时 conv）
            proj_wf = nn.Conv2d(refC, C_rgb, kernel_size=1).to(wf.device)
            wf_mapped = proj_wf(wf)  # [B, C_rgb, 1, 1]
        else:
            wf_mapped = wf

        # 应用通道-空间权重到 rgb 特征并融合
        x_rgb_adj = x_rgb * wf_mapped  # 广播
        fused = x_rgb_adj + x_fir
        return fused


# ---------------------------
# 其余新增模块（与之前实现一致）
# ---------------------------
class ResidualBlock(nn.Module):
    def __init__(self, c):
        super().__init__()
        self.block = nn.Sequential(
            nn.Conv2d(c, c, 3, padding=1),
            nn.ReLU(inplace=True),
            nn.Conv2d(c, c, 3, padding=1)
        )
    def forward(self, x):
        return x + self.block(x)

class MultiScaleFeatureFusion(nn.Module):
    def __init__(self, in_channels, mid_channels=None):
        super().__init__()
        C = in_channels
        if mid_channels is None:
            mid_channels = max(16, C)
        self.conv7_rgb = nn.Sequential(nn.Conv2d(C, mid_channels, 7, padding=3), nn.ReLU(inplace=True))
        self.conv7_fir = nn.Sequential(nn.Conv2d(C, mid_channels, 7, padding=3), nn.ReLU(inplace=True))
        self.down = nn.Sequential(nn.Conv2d(C, mid_channels, 3, stride=2, padding=1), nn.ReLU(inplace=True))
        self.res_small = nn.Sequential(ResidualBlock(mid_channels), ResidualBlock(mid_channels), ResidualBlock(mid_channels))
        self.up_small = nn.Sequential(nn.ConvTranspose2d(mid_channels, mid_channels, 4, stride=2, padding=1), nn.ReLU(inplace=True))
        self.rb_large_rgb = nn.Sequential(ResidualBlock(mid_channels), ResidualBlock(mid_channels), ResidualBlock(mid_channels))
        self.rb_large_fir = nn.Sequential(ResidualBlock(mid_channels), ResidualBlock(mid_channels), ResidualBlock(mid_channels))
        self.frct_rgb = nn.Sequential(nn.ReflectionPad2d(3), nn.Conv2d(mid_channels, mid_channels, 7), nn.Tanh())
        self.frct_fir = nn.Sequential(nn.ReflectionPad2d(3), nn.Conv2d(mid_channels, mid_channels, 7), nn.Tanh())
        self.out_conv = nn.Conv2d(mid_channels, C, kernel_size=1)

        # 一个小的 compress conv 用于把 concat 后通道数压回 C（避免 forward 中再创建临时 conv 引入不确定性）
        self.compress_after = nn.Conv2d(C, C, kernel_size=1)

    def forward(self, pixel_fused, rgb_feat):
        x_small = self.down(pixel_fused)
        x_small = self.res_small(x_small)
        x_small_up = self.up_small(x_small)
        x_small_up = self.frct_rgb(x_small_up)

        u_rgb = self.conv7_rgb(rgb_feat)
        u_fir = self.conv7_fir(pixel_fused)

        ur = u_rgb + x_small_up
        uf = u_fir + x_small_up

        ur = self.rb_large_rgb(ur)
        uf = self.rb_large_fir(uf)

        Grgb = self.frct_rgb(ur)
        Gfir = self.frct_fir(uf)

        XCF = Grgb + Gfir
        XCF = self.out_conv(XCF)
        E1_in = torch.cat([XCF + rgb_feat, ], dim=1)
        # compress E1_in 回到 channels C（使用模块中的 compress_after）
        # 注意：E1_in 的通道可能为 C (since we concatenated single tensor) — 保证形状兼容
        E1_in = self.compress_after(E1_in)
        return XCF, E1_in


class ChannelSE(nn.Module):
    def __init__(self, channels, reduction=16):
        super().__init__()
        self.fc = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(channels, max(1, channels // reduction), 1),
            nn.ReLU(inplace=True),
            nn.Conv2d(max(1, channels // reduction), channels, 1),
            nn.Sigmoid()
        )
    def forward(self, x):
        return x * self.fc(x)


class MultiScaleImageTransfer(nn.Module):
    def __init__(self, channels):
        super().__init__()
        self.channels = channels
        self.se = ChannelSE(channels)
        self.scale_convs = nn.ModuleList([
            nn.Sequential(nn.Conv2d(channels, channels, kernel_size=3, padding=1), nn.ReLU(inplace=True)),
            nn.Sequential(nn.Conv2d(channels, channels, kernel_size=3, padding=1), nn.ReLU(inplace=True)),
            nn.Sequential(nn.Conv2d(channels, channels, kernel_size=3, padding=1), nn.ReLU(inplace=True)),
            nn.Sequential(nn.Conv2d(channels, channels, kernel_size=3, padding=1), nn.ReLU(inplace=True))
        ])
        self.final_merge = nn.Sequential(
            nn.Conv2d(channels * 5, channels, kernel_size=3, padding=1),
            nn.Tanh()
        )
        self.post_conv = nn.Conv2d(channels, channels, kernel_size=3, padding=1)

    def forward(self, Pin, Xcf):
        Pin_se = self.se(Pin)
        B, C, H, W = Pin_se.shape
        scales = [4, 8, 16, 32]
        outs = []
        for idx, s in enumerate(scales):
            target_h = max(1, H // s)
            target_w = max(1, W // s)
            small = F.adaptive_avg_pool2d(Pin_se, (target_h, target_w))
            small = self.scale_convs[idx](small)
            small_up = F.interpolate(small, size=(H, W), mode='bilinear', align_corners=False)
            outs.append(small_up)

        concat = torch.cat([Pin_se, *outs], dim=1)
        merged = self.final_merge(concat)
        E1_out = merged
        combined = E1_out + Xcf
        E2_out = self.post_conv(combined)
        return E2_out


# ---------------------------
# 整合到主网络
# ---------------------------
class MFCL(nn.Module):
    def __init__(self, dim=32, dim_mults=(1, 2, 4, 8), num_blocks_encoder=1, num_blocks_decoder=1):
        super().__init__()
        self.init_conv_rgb = nn.Conv2d(3, dim, 7, padding=3)
        self.encoder_rgb = Encoder(dim, dim_mults, num_blocks=num_blocks_encoder)

        self.init_conv_nir = nn.Conv2d(1, dim, 7, padding=3)
        self.encoder_nir = Encoder(dim, dim_mults, num_blocks=num_blocks_encoder)

        self.cmca = CMCA_PixelFusion(dim, pool_kernel_sizes=(3, 7))
        self.ms_ff = MultiScaleFeatureFusion(in_channels=dim)
        self.transfer = MultiScaleImageTransfer(dim)

        encoder_dims = [dim * m for m in dim_mults]
        mid_dim = encoder_dims[-1]
        self.mid_block = nn.Sequential(Block(mid_dim, mid_dim), Block(mid_dim, mid_dim))

        self.decoder = Decoder(dim, dim_mults, num_blocks=num_blocks_decoder)
        self.transfer_proj = nn.Conv2d(dim, dim, kernel_size=1)
        self.final_conv = nn.Conv2d(dim, 3, 3, padding=1)

    def forward(self, rgb, nir):
        x_rgb_init = self.init_conv_rgb(rgb)
        x_nir_init = self.init_conv_nir(nir)

        pixel_fused = self.cmca(x_rgb_init, x_nir_init)

        skips_rgb, x_rgb = self.encoder_rgb(x_rgb_init)
        skips_nir, x_nir = self.encoder_nir(x_nir_init)

        x = x_rgb + x_nir
        x = self.mid_block(x)

        fused_skips = []
        for s_rgb, s_nir in zip(skips_rgb, skips_nir):
            fused_skip = self.cmca(s_rgb, s_nir)
            fused_skips.append(fused_skip)

        Xcf, E1_in = self.ms_ff(pixel_fused, x_rgb_init)
        E2_out = self.transfer(E1_in, Xcf)

        x = self.decoder(x, fused_skips)

        if E2_out.shape[2:] != x.shape[2:]:
            E2_proj = F.interpolate(E2_out, size=x.shape[2:], mode='bilinear', align_corners=False)
        else:
            E2_proj = E2_out
        E2_proj = self.transfer_proj(E2_proj)

        final_feat = x + E2_proj
        out = self.final_conv(final_feat)
        return out


# ---------------------------
# 简单的 FLOPs/Params 测试
# ---------------------------
def calculate_flops_params():
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    print(f"Using device: {device}")

    model = MFCL(dim=32, dim_mults=(1, 2, 4, 8),
                           num_blocks_encoder=[2, 2, 2, 2],
                           num_blocks_decoder=[2, 2, 2, 2]).to(device)

    rgb_input = torch.randn(1, 3, 256, 256).to(device)
    nir_input = torch.randn(1, 1, 256, 256).to(device)

    model.eval()
    with torch.no_grad():
        start = time.time()
        result = model(rgb_input, nir_input)
        end = time.time()
        print(f"Forward pass time: {(end - start) * 1000:.2f} ms")
        print("Output shape:", tuple(result.shape))

    model.to('cpu')
    rgb_input = rgb_input.to('cpu')
    nir_input = nir_input.to('cpu')

    try:
        flops, params = profile(model, inputs=(rgb_input, nir_input), verbose=False)
        gflops = flops / 1e9
        params_m = params / 1e6
        print(f"FLOPs: {gflops:.2f} G")
        print(f"Params: {params_m:.2f} M")
    except Exception as e:
        print(f"Could not calculate FLOPs and Params: {e}")
        print("Ensure thop is installed (`pip install thop`) and inputs/model are on CPU for profile.")


if __name__ == "__main__":
    calculate_flops_params()
