""" Full assembly of the parts to form the complete network """

from .unet_part import *


class UNet(nn.Module):
    def __init__(self, n_channels, bilinear=True):
        super(UNet, self).__init__()
        self.n_channels = n_channels
        self.bilinear = bilinear

        self.inc = DoubleConv(n_channels, 64)
        self.down1 = Down(64, 128)
        self.down2 = Down(128, 256)
        self.down3 = Down(256, 512)
        factor = 2 if bilinear else 1
        self.down4 = Down(512, 1024 // factor)
        self.up1 = Up(1024, 512 // factor, bilinear)
        self.up2 = Up(512, 256 // factor, bilinear)
        self.up3 = Up(256, 128 // factor, bilinear)
        self.up4 = Up(128, 64, bilinear)
        self.outc = OutConv(64, 3)

    def forward(self, inp):
        x = inp
        x1 = self.inc(x)
        x2 = self.down1(x1)
        x3 = self.down2(x2)
        x4 = self.down3(x3)
        x5 = self.down4(x4)
        x = self.up1(x5, x4)
        x = self.up2(x, x3)
        x = self.up3(x, x2)
        x = self.up4(x, x1)
        x = self.outc(x) + inp
        return x

'''data = torch.randn(2, 3, 128, 128).to("cuda")
model = UNet(n_channels=3).to("cuda")
print(model(data).shape)'''

def count_param(model):
    param_count = 0
    for param in model.parameters():
        param_count += param.view(-1).size()[0]
    return param_count

from thop import profile # Make sure this is uncommented

if __name__ == "__main__":
    model = UNet(n_channels=3).to("cuda")
    model.eval()
    print("params", count_param(model))
    inputs = torch.randn(2, 3, 256, 256).to("cuda")
    result = model(inputs)

    flops, params = profile(model, inputs=(inputs,), verbose=False)
    print(f"FLOPs: {flops / 1e9:.2f} GFLOPs") # Convert to GFLOPs for readability
    print(f"Params: {params / 1e6:.2f} M") # Convert to Millions for readability
